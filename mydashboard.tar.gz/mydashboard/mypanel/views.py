# Copyright 2012 United States Government as represented by the
# Administrator of the National Aeronautics and Space Administration.
# All Rights Reserved.
#
# Copyright 2012 Nebula, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from horizon import tabs
from openstack_dashboard.dashboards.mydashboard.mypanel import tabs as mydashboard_tabs

import logging
LOG = logging.getLogger(__name__)

from horizon import exceptions, tables, workflows, forms, tabs
 


from openstack_dashboard.dashboards.mydashboard.mypanel.forms import AddNode


from openstack_dashboard.dashboards.mydashboard.mypanel \
    import forms as project_forms

from django.core.urlresolvers import reverse
from django.core.urlresolvers import reverse_lazy
from horizon.utils import memoized
from openstack_dashboard import api

class IndexView(tabs.TabbedTableView):
    tab_group_class = mydashboard_tabs.MypanelTabs
    # A very simple class-based view...
    template_name = 'mydashboard/mypanel/index.html'

    def get_data(self, request, context, *args, **kwargs):
        # Add data to the context here...
        return context



class AddNodeView(workflows.WorkflowView):
    workflow_class = AddNode
 
    def get_initial(self):
        initial = super(AddNodeView, self).get_initial()
        return initial


class ShowDetailsView(forms.ModalFormView):
    form_class = project_forms.ShowDetails
    template_name = 'mydashboard/mypanel/show_details.html'
    submit_label = ("Details")

    def get_initial(self):

	inf = api.iotronic.get_info(self.request, self.kwargs['uuid'])
        
        code = inf[0].encode("utf-8")
	lat = inf[1][0]['latitude'].encode("utf-8")
	lon = inf[1][0]['longitude'].encode("utf-8")
	alt = inf[1][0]['altitude'].encode("utf-8")
	session = str(inf[2]).encode("utf-8")
	device = inf[3].encode("utf-8")
	mobile = str(inf[4]).encode("utf-8")


        return {"node_id": code, \
                "coo1":  lat, \
		"coo2": lon, \
		"coo3":alt, \
		"session": session, \
		"device": device, \
		"mobile": mobile}














