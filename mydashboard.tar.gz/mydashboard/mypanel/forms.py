import traceback
 
from horizon import workflows, forms, exceptions
from django.utils.translation import ugettext_lazy as _
from django.core.urlresolvers import reverse
from openstack_dashboard import api

import logging
LOG = logging.getLogger(__name__)



class SetAddNodeDetailsAction(workflows.Action):

    code_id = forms.CharField(label=_("NodeID"), max_length=8)
    name = forms.CharField(max_length=255, label=_("DeviceName"))

    type = forms.CharField(max_length=255, label=_("DeviceType"))
    coo1 = forms.FloatField(label=_("Latitude"))
    coo2 = forms.FloatField(label=_("Longitude"))
    coo3 = forms.FloatField(label=_("Height"))
 
    class Meta:
        name = _("Enter the information of the node")
 
    def __init__(self, request, context, *args, **kwargs):
        self.request = request
        self.context = context
        super(SetAddNodeDetailsAction, self).__init__(request, context, *args, **kwargs)
 
class SetAddNodeDetails(workflows.Step):
    action_class = SetAddNodeDetailsAction
    contributes = ("NodeID", "DeviceName", "DeviceType", "Latitude", "Longitude", "Height")
 
    def contribute(self, data, context):
        if data:
            context['NodeID'] = data.get("code_id", "")
            context['DeviceName'] = data.get("name", "")
            context['DeviceType'] = data.get("type", "")
            context['Latitude'] = data.get("coo1", "")
            context['Longitude'] = data.get("coo2", "")
            context['Height'] = data.get("coo3", "")
	    
        return context
 
class AddNode(workflows.Workflow):
    slug = "add"
    name = _("Add Node")
    finalize_button_name = _("Add")
    success_message = _('Added Node "%s".')

    success_url = "horizon:mydashboard:mypanel:index"
    failure_url = "horizon:mydashboard:mypanel:index"
    default_steps = (SetAddNodeDetails,)
 
    def format_status_message(self, message):
         return message % self.context.get('DeviceName', 'Unknown Node')
 
    def handle(self, request, context):
        try:
	    api.iotronic.node_create(self.request,context)
            return True
        except Exception:
	    for node in api.iotronic.node_list(self.request):
	        if context['NodeID'] == node.code:
            	    exceptions.handle(request, _("Unable to add Node: it already exists"))
		    return False
	    
            exceptions.handle(request, _("Unable to add Node: API doesn't work"))
            return False

class ShowDetails(forms.SelfHandlingForm):
     node_id = forms.CharField(label=_("Node id"))
     coo1 = forms.CharField(label=_("Latitude"))
     coo2 = forms.CharField(label=_("Longitude"))
     coo3 = forms.CharField(label=_("Height"))
     session = forms.CharField(label=_("Session"))
     device = forms.CharField(label=_("Device Type"))
     mobile = forms.CharField(label=_("Mobile"))


       
     def handle(self, request,data):
        return True



