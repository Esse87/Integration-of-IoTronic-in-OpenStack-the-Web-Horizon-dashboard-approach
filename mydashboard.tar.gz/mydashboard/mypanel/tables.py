# Copyright 2012 Nebula, Inc.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from django.utils.translation import ugettext_lazy as _
from django.utils.translation import ungettext_lazy 
from horizon import forms
from horizon import tables
from openstack_dashboard import api



class UpdateNode(tables.LinkAction):
    name = "update_node"
    verbose_name = _("Update Node")
    ajax = False
    icon = "pencil"
    attrs = {"ng-controller": "MetadataModalHelperController as modal"}

   

    def get_link_url(self, datum):

        return "javascript:void(0);"

class DetailsAction(tables.LinkAction):
    name = "details"
    verbose_name = _("Details Node")
    url = "horizon:mydashboard:mypanel:show_details"
    classes = ("btn-launch", "ajax-modal")
 
class AddTableNode(tables.LinkAction):
    name = "add"
    verbose_name = _("Add Node")
    url = "horizon:mydashboard:mypanel:add"
    classes = ("btn-launch", "ajax-modal")
    icon = "plus"
    

class UpdateRow(tables.Row):
    ajax = True
 
    def get_data(self, request, post_id):
        pass

class DeleteNodesAction(tables.DeleteAction):
    @staticmethod
    def action_present(count):
        return ungettext_lazy(
            u"Delete Node",
            u"Delete Node",
            count
        )

    @staticmethod
    def action_past(count):
        return ungettext_lazy(
            u"Deleted Node",
            u"Deleted Node",
            count
        )
       
    def delete(self, request, uuid ):
        
        api.iotronic.node_delete(request, uuid)


class NodesFilterAction(tables.FilterAction):
    name = "Filter Nodes"

class TextualTable(tables.DataTable):
    name = tables.Column("name", verbose_name=_("Name"))
    status = tables.Column("status", verbose_name=_("Status"))
    uuid = tables.Column("uuid", verbose_name=_("UUID"))
       

    class Meta(object):
        name = "nodes"
        verbose_name = _("Nodes")
        row_class = UpdateRow
        table_actions = (AddTableNode, DeleteNodesAction, NodesFilterAction)
        row_actions = (DeleteNodesAction, DetailsAction, UpdateNode,)

"""
class MapTable(tables.DataTable):
   
    class Meta(object):
        name = ""
        verbose_name = _("")
        table_actions = ()
        row_actions = ()"""

